```markdown
# Design System Specification: The Kinetic Vault

## 1. Overview & Creative North Star
**Creative North Star: The Neon Editorial**
This design system rejects the cluttered, "utility-first" aesthetic of traditional game launchers in favor of a high-end editorial experience. We treat every game title like a cinematic release. By combining the technical precision of geometric typography with a "void-space" philosophy, we create an environment where games feel like curated artifacts rather than database entries.

The system breaks the traditional grid through **Intentional Asymmetry**. Instead of a uniform wall of posters, we use varying card scales and overlapping typography to create a sense of motion and depth. This is not just a store; it is a premium digital gallery for the modern gamer.

---

## 2. Colors & Tonal Depth
Our palette is rooted in the "Deep Void" (`background: #0e0e13`), allowing our neon accents (`primary`, `secondary`, `tertiary`) to act as light sources within the interface.

*   **The "No-Line" Rule:** To maintain a bespoke, premium feel, 1px solid borders are strictly prohibited for sectioning. Separation of content must be achieved through:
    *   **Background Shifts:** Transitioning from `surface` to `surface-container-low`.
    *   **Tonal Transitions:** Using subtle shifts in the surface hierarchy to define edges.
*   **Surface Hierarchy & Nesting:** Treat the UI as layers of physical material. 
    *   **Base:** `surface` (#0e0e13)
    *   **Sections:** `surface-container-low` (#131318)
    *   **Floating Cards:** `surface-container-high` (#1f1f26)
    *   **Active/Pop-over:** `surface-container-highest` (#25252c)
*   **The "Glass & Gradient" Rule:** Primary actions and hero elements should utilize glassmorphism. Use `surface_variant` at 40% opacity with a `40px` backdrop blur to allow game art to bleed through the interface.
*   **Signature Textures:** Main CTAs should never be flat. Use a linear gradient from `primary` (#8ff5ff) to `primary_container` (#00eefc) at a 135-degree angle to provide a "lit" neon-tube effect.

---

## 3. Typography
We utilize a dual-typeface system to balance futuristic high-tech energy with ultra-legibility.

*   **Display & Headlines (Space Grotesk):** This is our "Tech-Voice." Used for game titles (`display-lg`) and section headers (`headline-md`). It should feel architectural. Use `display-lg` (3.5rem) with tighter letter-spacing (-0.02em) for a high-end editorial look.
*   **Body & Titles (Manrope):** Our "Functional-Voice." Manrope provides the readability required for long-form game descriptions (`body-md`) and metadata (`label-sm`).
*   **The Hierarchy Goal:** Create a massive contrast between `display-lg` and `body-sm`. This "size-gap" is what removes the "template" look and introduces professional editorial pacing.

---

## 4. Elevation & Depth
In this system, depth is a product of light, not structure.

*   **The Layering Principle:** Stack `surface-container` tiers to create lift. A `surface-container-lowest` card sitting on a `surface-container-low` background creates a natural "recessed" look without a single stroke or shadow.
*   **Ambient Shadows:** For floating modals, use an extra-diffused shadow. 
    *   *Shadow Definition:* `0px 24px 48px rgba(0, 0, 0, 0.5)`. The shadow should feel like a soft occlusion of light rather than a hard edge.
*   **The "Ghost Border":** When structural definition is required for accessibility, use the `outline_variant` token at **15% opacity**. This creates a hint of an edge that only appears when the user’s eye seeks it out.
*   **Glassmorphism:** Apply to navigation bars and game-buy overlays. Use `surface_variant` (semi-transparent) + `backdrop-filter: blur(20px)`. This integrates the UI into the game’s vibrant artwork.

---

## 5. Components

### Cards & Discovery
*   **Rule:** No dividers. Use `xl` (0.75rem) roundedness for game posters.
*   **Layout:** Game cards in the "Discovery" section should use `surface-container-high`. On hover, scale the card by 1.02% and transition the background to `surface-container-highest`.
*   **Metadata:** Use `label-md` for genre tags, housed in `secondary_container` capsules with `full` roundedness.

### Buttons
*   **Primary:** Linear gradient (`primary` to `primary_container`). `xl` roundedness. Text is `on_primary_fixed` (Deep Teal).
*   **Secondary:** Ghost style. No fill, `outline_variant` at 20% opacity. Text is `primary`.
*   **Tertiary/Utility:** `surface_container_highest` fill with `on_surface` text.

### Inputs & Search
*   **Field:** `surface_container_low` fill, `none` border, `md` roundedness. 
*   **Active State:** Underline only using a 2px `primary` stroke. This mimics a laser-line aesthetic.

### Chips (Game Tags)
*   **Selection Chips:** Use `secondary_container` for the background and `on_secondary_container` for text. No borders.
*   **Interaction:** On hover, apply a `primary_dim` glow (box-shadow: 0 0 15px).

### Lists
*   **Rule:** Forbid 1px dividers. Use a `16px` vertical gap between items. 
*   **Visual Separation:** Use alternating backgrounds (`surface` and `surface-container-low`) for long library lists to guide the eye.

---

## 6. Do's and Don'ts

### Do
*   **Do** use `tertiary` (#ff59e3) for "Sale" or "New" indicators to create high-contrast urgency.
*   **Do** use asymmetrical layouts (e.g., a 2-column wide featured game next to a 1-column tall list).
*   **Do** leverage the `surface_tint` for subtle glows on active icons.
*   **Do** allow game imagery to be the "hero"—UI elements should feel like they are floating on top of the art.

### Don't
*   **Don't** use pure `#ffffff` for text. Use `on_surface` (#f8f5fd) to prevent eye strain in dark environments.
*   **Don't** use 100% opaque `outline` tokens. It breaks the "Kinetic" flow of the dark theme.
*   **Don't** use "Drop Shadows" on cards unless they are in a floating/modal state. Use tonal layering instead.
*   **Don't** clutter the screen. If a piece of information isn't vital to the "Discovery" phase, hide it in a `surface-container-highest` tooltip.```